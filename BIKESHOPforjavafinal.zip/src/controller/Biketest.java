/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author dominick valentine
 */
// you need to run Menu for it to start
// have every gui have menu and exit buttons so the user can end or go back to start
// put some read data in the bikes file so its looks real
// since all the methods are reading from the same file just have FakeBikeDAO have the methods and call them thought 
// a BikeDAO or EbikeDAO object 
//make a sub class of bike called ebike and the only different is the battery wats and battery life,
//make the gui simalir to the bike Gui but with the added attduies in it, and 
//move the guis around so they are in their own pack and along with the other classes.
// and the bike classwrite both bikes and write 
 //ebikes to the same bike text file, Read should stay the same , 
// this is the class for the find method
// add all the guis to the menu so everything can connect
//all the frames will be simalr 
// 
class Biketest {
}